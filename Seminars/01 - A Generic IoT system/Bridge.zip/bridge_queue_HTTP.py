### author: Roberto Vezzani
import serial
import serial.tools.list_ports
import random
import configparser

# MQTT
import paho.mqtt.client as mqtt

# HTTP REST
import requests

#queue
import threading
import queue



class BridgeWithQueue_HTTP():

	def __init__(self):
		self.config = configparser.ConfigParser()
		self.config.read('config.ini')
		self.setupData()
		self.setupQueue()
		self.setupSerial()


	def setupData(self):
		self.sums=[]
		self.counters=[]


	def setupQueue(self):
		self.q = queue.Queue()

	def setupSerial(self):
		print("list of available ports: ")
		ports = serial.tools.list_ports.comports()
		for port in ports:
			print (port.device)
			print (port.description)

		# open serial port
		self.ser = None
		if self.config.getboolean("Serial","UseDescription", fallback=False):
			for port in ports:
				if self.config.get("Serial","PortDescription", fallback="arduino").lower() \
						in port.description.lower():
					self.portname = port.device
		else:
			self.portname = self.config.get("Serial","PortName", fallback="COM1")

		try:
			if self.portname is not None:
				print ("connecting to " + self.portname)
				self.ser = serial.Serial(self.portname, 9600, timeout=4)
		except:
			self.ser = None
			print("Invalid serial port")
			exit(0)

		# internal input buffer from serial
		self.inbuffer = ""
		# Turn-on the serial thread.
		threading.Thread(target=self.serialchecker, daemon=True).start()

	def serialchecker(self):
		# infinite loop for serial managing
		while (True):
			#look for a byte from serial
			if not self.ser is None:
				# read 1 byte
				lastbyte=self.ser.read(1)
				lastchar=lastbyte.decode("utf-8")

				if lastchar=="\n": #LF
					print("\nValue received")
					self.q.put(self.inbuffer)
					self.inbuffer =""
				else:
					# append
					self.inbuffer += lastchar


	def loop(self):
		# infinite loop
		#
		while (True):
			# get an item from the queue
			try:
				item=self.q.get(True,timeout=6)
				parts=item.split(";")
				numparts=int(parts[0])
				msg = dict()
				for i in range (numparts):
					val = float(parts[i+1])
					strval = "Sensor %d: %f " % (i, val)
					print(strval)
					if len(self.sums) < i+1:
						self.sums.insert(i,0)
						self.counters.insert(i,0)
					self.sums[i]+=val
					self.counters[i]+=1

					if self.counters[i]>= self.config.getint("DEFAULT","SendFrequency", fallback=10):

						key=f'key{i+1}'
						meanVal = self.sums[i] / self.counters[i]
						msg[key]=meanVal


						self.sums[i] = 0
						self.counters[i] = 0
				if len(msg)>0:
					URLPost = self.config.get("HTTP", "UrlPostTelemetry", fallback="")
					mypost = requests.post(url=URLPost, data=str(msg))
					print(mypost.text)

			except queue.Empty:
				print("debug: empty queue")
				pass
			except:
				print("error")
				pass



if __name__ == '__main__':
	br=BridgeWithQueue_HTTP()
	br.loop()

