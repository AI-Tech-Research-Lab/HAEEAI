### author: Roberto Vezzani

import configparser

# MQTT
import time

import paho.mqtt.client as mqtt
import datetime

# HTTP REST
import requests

class AnomalyDetector():

	def __init__(self):
		self.config = configparser.ConfigParser()
		self.config.read('config.ini')
		self.setupHTTP()


	def setupHTTP(self):
		# request and save the token
		url =  self.config.get("HTTP", "UrlLogin", fallback="")
		username=self.config.get("HTTP", "Username", fallback="")
		password = self.config.get("HTTP", "Password", fallback="")
		strdata =f'{{"username":"{username}", "password":"{password}"}}'
		print(strdata)
		mypost = requests.post(url=url,data=strdata)

		self.token=mypost.json().get("token","")
		print(self.token)

	def loop(self):
		while (True):
			self.runOnce()
			time.sleep(600)  # run every 10 minutes

	def runOnce(self):
		# request and save the token
		url = self.config.get("HTTP", "UrlLastDayTelemetry", fallback="")
		deviceID = self.config.get("HTTP", "DEVICEID", fallback="")
		url=url.replace("$DEVICEID$",deviceID)
		headers= {'X-Authorization':f'Bearer {self.token}'}


		mseconds_since_end = int(datetime.datetime.now().timestamp()*1000)
		mseconds_since_start = mseconds_since_end - 1 * 24 * 60 * 60 * 1000

		url += f'&startTs={mseconds_since_start}&endTs={mseconds_since_end}'

		myget = requests.get(url=url, headers=headers)
		print(myget.text)

		print("based on this temporal sequence, train a forecaster, predict a value and compare it with the next value(s)")

if __name__ == '__main__':
	br=AnomalyDetector()
	br.runOnce()

